#!/bin/bash
cd pallets/progress-smart-site
npm install
npm run build
npm run start