import React, { useEffect, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { ImagePlaceholder } from '../assets/imagePlaceholders';
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";

// Import images
import podcastStudioImage from "../assets/images/podcast_studio.jpg";

// Form schema for the booking form
const formSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(6, { message: "Please enter a valid phone number." }),
  date: z.date({ required_error: "Please select a date." }),
  sessionType: z.enum(["podcast", "video", "both"], { required_error: "Please select a session type." }),
  addons: z.array(z.string()).optional(),
  message: z.string().optional(),
});

// Feature cards data
const studioFeatures = [
  {
    title: "Two-camera setup",
    description: "Professional DSLR cameras with interchangeable lenses",
    imageName: "feature_camera_setup.jpg"
  },
  {
    title: "Two pro podcast mics",
    description: "Broadcast-quality audio capture for crystal clear sound",
    imageName: "feature_podcast_mics.jpg"
  },
  {
    title: "Live camera preview on TV",
    description: "See yourself in real-time while recording",
    imageName: "feature_tv_preview.jpg"
  },
  {
    title: "4K TV for slides/playback",
    description: "Present slide decks or review footage instantly",
    imageName: "feature_presentation_tv.jpg"
  },
  {
    title: "Two-person podcast setup",
    description: "Perfect for interviews and conversations",
    imageName: "feature_interview_setup.jpg"
  },
  {
    title: "Professional lighting rig",
    description: "Look your best with studio-quality lighting",
    imageName: "feature_lighting.jpg"
  },
  {
    title: "Acoustically treated space",
    description: "No echo, no background noise, just perfect audio",
    imageName: "feature_acoustic_panels.jpg"
  },
  {
    title: "On-site studio tech support",
    description: "Expert help with setup and recording",
    imageName: "feature_technician.jpg"
  },
  {
    title: "Editing desk + workspace",
    description: "Comfortable space to review and edit your content",
    imageName: "feature_edit_desk.jpg"
  }
];

// Pricing table data
const pricingOptions = [
  { package: "One-hour session", price: "£60" },
  { package: "Half-day bundle (4 hours)", price: "£200" },
  { package: "Full-day bundle (8 hours)", price: "£350" },
  { package: "Monthly Creator Pass (4x 1hr)", price: "£199/month" }
];

// Benefits list
const benefits = [
  "No DIY setups or echoey home audio",
  "No commute to Oxford or London",
  "Instant content credibility",
  "Walk in with an idea, walk out with content",
  "Friendly tech setup included"
];

export default function StudioPage() {
  // Animation setup
  const sectionRefs = {
    hero: useRef<HTMLElement>(null),
    features: useRef<HTMLElement>(null),
    location: useRef<HTMLElement>(null),
    pricing: useRef<HTMLElement>(null),
    why: useRef<HTMLElement>(null),
    upsell: useRef<HTMLElement>(null),
    booking: useRef<HTMLElement>(null)
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
          }
        });
      },
      { threshold: 0.1 }
    );

    Object.values(sectionRefs).forEach((ref) => {
      if (ref.current) {
        observer.observe(ref.current);
      }
    });

    return () => {
      Object.values(sectionRefs).forEach((ref) => {
        if (ref.current) {
          observer.unobserve(ref.current);
        }
      });
    };
  }, []);

  // Form setup
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: "",
      addons: [],
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    console.log(values);
    alert("Thank you for your booking request! We'll be in touch shortly.");
    form.reset();
  }

  return (
    <>
      {/* Hero Section */}
      <section 
        ref={sectionRefs.hero}
        className="py-16 md:py-24 fade-in-section" 
        style={{ backgroundColor: 'var(--navy)' }}
      >
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 md:pr-8 text-white">
              <h1 className="font-poppins font-bold text-3xl md:text-5xl mb-4">
                🎙️ Podcast & Video Studio Hire in Banbury
              </h1>
              <h2 className="font-poppins text-xl md:text-2xl mb-6 text-gray-200">
                Broadcast-quality. Acoustically treated. Fully supported.
              </h2>
              <p className="text-lg mb-6 text-gray-300">
                Looking for a professional video or podcast studio near Banbury? The Progress Studio is a fully equipped broadcast-quality space — purpose-built for small business owners, creators, and content-first brands who want to sound and look incredible without travelling miles or renting a London setup.
              </p>
              <div className="bg-white/10 p-6 rounded-lg mb-6">
                <p className="text-lg mb-2">
                  <span className="font-bold text-white">Progress clients?</span> You get free studio access every month.
                </p>
                <p className="text-lg">
                  <span className="font-bold text-white">Other businesses?</span> You're more than welcome to book too.
                </p>
              </div>
              <a href="#booking-form">
                <Button 
                  size="lg" 
                  style={{ backgroundColor: 'var(--orange)' }}
                  className="px-8 py-6 text-lg glow-on-hover hover:-translate-y-[2px] transition duration-300"
                >
                  Book Studio Time
                </Button>
              </a>
            </div>
            <div className="md:w-1/2 mt-10 md:mt-0 image-container">
              {/* Real studio image */}
              <div className="rounded-lg overflow-hidden shadow-lg">
                <img 
                  src={podcastStudioImage} 
                  alt="Professional Podcast & Video Studio"
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section 
        ref={sectionRefs.features}
        id="features" 
        className="py-16 md:py-24 bg-white fade-in-section"
      >
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h3 
              className="font-poppins font-bold text-2xl md:text-3xl mb-6"
              style={{ color: 'var(--navy)' }}
            >
              What's included in every session
            </h3>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6">
            {studioFeatures.map((feature, index) => (
              <Card 
                key={index} 
                className="hover-scale transition duration-300 shadow-md overflow-hidden"
              >
                <div className="h-48 overflow-hidden">
                  <ImagePlaceholder 
                    height="100%" 
                    text={feature.title}
                    bgColor={index % 2 === 0 ? '#1a365d' : '#f27030'}
                  />
                </div>
                <CardContent className="p-6">
                  <h4 
                    className="font-poppins font-semibold text-lg mb-2"
                    style={{ color: 'var(--navy)' }}
                  >
                    {feature.title}
                  </h4>
                  <p style={{ color: 'var(--dark-grey)' }}>
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section 
        ref={sectionRefs.location}
        id="location" 
        className="py-16 md:py-24 fade-in-section"
        style={{ backgroundColor: 'var(--light-grey)' }}
      >
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-10">
            <div className="md:w-1/2">
              <div className="rounded-lg overflow-hidden shadow-lg">
                <ImagePlaceholder 
                  height="350px" 
                  text="Studio Location Map" 
                  bgColor="#f27030"
                />
              </div>
            </div>
            <div className="md:w-1/2">
              <h3 
                className="font-poppins font-bold text-2xl md:text-3xl mb-4"
                style={{ color: 'var(--navy)' }}
              >
                Perfectly located in Banbury
              </h3>
              <p className="text-lg mb-6" style={{ color: 'var(--dark-grey)' }}>
                We're based just off Banbury town centre in Oxfordshire — ideal for businesses from Oxford, Bicester, Leamington Spa, Brackley, and beyond. Free parking available.
              </p>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h4 className="font-semibold mb-2" style={{ color: 'var(--navy)' }}>Address:</h4>
                <p style={{ color: 'var(--dark-grey)' }}>
                  Progress Studio<br />
                  123 Business Way<br />
                  Banbury<br />
                  Oxfordshire<br />
                  OX16 1AB
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Table Section */}
      <section 
        ref={sectionRefs.pricing}
        id="pricing" 
        className="py-16 md:py-24 bg-white fade-in-section"
      >
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-8">
            <h3 
              className="font-poppins font-bold text-2xl md:text-3xl mb-4"
              style={{ color: 'var(--navy)' }}
            >
              Studio Hire Rates
            </h3>
            <p 
              className="text-lg mb-6 flex items-center justify-center"
              style={{ color: 'var(--dark-grey)' }}
            >
              <span className="text-2xl mr-2">🎁</span>
              Progress Accountants clients get 1 hour of free studio use every month (included in all plans).
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto shadow-lg rounded-lg overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow style={{ backgroundColor: 'var(--navy)', color: 'white' }}>
                  <TableHead className="text-white font-medium w-2/3">Package</TableHead>
                  <TableHead className="text-white font-medium text-right">Price</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pricingOptions.map((option, index) => (
                  <TableRow key={index} style={{ backgroundColor: index % 2 === 0 ? 'white' : 'var(--light-grey)' }}>
                    <TableCell className="font-medium">{option.package}</TableCell>
                    <TableCell className="text-right font-bold" style={{ color: 'var(--navy)' }}>{option.price}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
              <TableCaption className="py-3 bg-gray-50">
                All bookings include tech support, lighting, and edit-ready output.
              </TableCaption>
            </Table>
          </div>
        </div>
      </section>

      {/* Why Book With Us Section */}
      <section 
        ref={sectionRefs.why}
        id="why-us" 
        className="py-16 md:py-24 text-white fade-in-section"
        style={{ backgroundColor: 'var(--navy)' }}
      >
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h3 className="font-poppins font-bold text-2xl md:text-3xl mb-4">
              Why choose the Progress Studio?
            </h3>
          </div>
          
          <div className="grid md:grid-cols-2 gap-x-16 gap-y-6 max-w-4xl mx-auto">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-start">
                <div style={{ color: 'var(--orange)' }} className="text-xl mr-3 mt-1">✓</div>
                <p className="text-lg">{benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Subtle Upsell Block */}
      <section 
        ref={sectionRefs.upsell}
        id="upsell" 
        className="py-16 md:py-20 fade-in-section"
        style={{ backgroundColor: 'var(--light-grey)' }}
      >
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-lg p-8 md:p-12 text-center">
            <h3 
              className="font-poppins font-bold text-2xl md:text-3xl mb-4"
              style={{ color: 'var(--navy)' }}
            >
              Want it for free?
            </h3>
            <p className="text-lg mb-6" style={{ color: 'var(--dark-grey)' }}>
              Our clients don't just get great financial advice — they also get tools to grow their brand.
              All Progress clients receive 1 hour of free studio time per month, perfect for recording podcasts, sales videos, or expert content.
            </p>
            <a href="/">
              <Button 
                style={{ backgroundColor: 'var(--orange)' }}
                className="px-6 py-4 text-lg glow-on-hover hover:-translate-y-[2px] transition duration-300"
              >
                👉 Explore our client plans
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Booking Form Section */}
      <section 
        ref={sectionRefs.booking}
        id="booking-form" 
        className="py-16 md:py-24 bg-white fade-in-section"
      >
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h3 
                className="font-poppins font-bold text-2xl md:text-3xl mb-4"
                style={{ color: 'var(--navy)' }}
              >
                Book your studio session
              </h3>
              <p className="text-lg" style={{ color: 'var(--dark-grey)' }}>
                Fill out the form below and we'll get back to you within 24 hours to confirm your booking.
              </p>
            </div>
            
            <div className="bg-white shadow-lg rounded-lg p-8 border border-gray-100">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Your name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="Your email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone</FormLabel>
                          <FormControl>
                            <Input placeholder="Your phone number" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>Preferred Date & Time</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>Pick a date</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="sessionType"
                    render={({ field }) => (
                      <FormItem className="space-y-3">
                        <FormLabel>Session Type</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex flex-col space-y-1"
                          >
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="podcast" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">
                                Podcast
                              </FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="video" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">
                                Video
                              </FormLabel>
                            </FormItem>
                            <FormItem className="flex items-center space-x-3 space-y-0">
                              <FormControl>
                                <RadioGroupItem value="both" />
                              </FormControl>
                              <FormLabel className="font-normal cursor-pointer">
                                Both
                              </FormLabel>
                            </FormItem>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="addons"
                    render={() => (
                      <FormItem>
                        <div className="mb-2">
                          <FormLabel>Add-ons (optional)</FormLabel>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                          {["Editing support", "Slides preparation", "Not sure yet"].map(
                            (addon) => (
                              <FormField
                                key={addon}
                                control={form.control}
                                name="addons"
                                render={({ field }) => {
                                  return (
                                    <FormItem
                                      key={addon}
                                      className="flex flex-row items-start space-x-3 space-y-0"
                                    >
                                      <FormControl>
                                        <Checkbox
                                          checked={field.value?.includes(addon)}
                                          onCheckedChange={(checked) => {
                                            return checked
                                              ? field.onChange([
                                                  ...(field.value || []),
                                                  addon,
                                                ])
                                              : field.onChange(
                                                  field.value?.filter(
                                                    (value) => value !== addon
                                                  )
                                                );
                                          }}
                                        />
                                      </FormControl>
                                      <FormLabel className="font-normal cursor-pointer">
                                        {addon}
                                      </FormLabel>
                                    </FormItem>
                                  );
                                }}
                              />
                            )
                          )}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Message (optional)</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Tell us a bit about what you want to record..."
                            className="resize-none"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full py-6"
                    style={{ backgroundColor: 'var(--orange)' }}
                  >
                    Submit Booking Request
                  </Button>
                </form>
              </Form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}