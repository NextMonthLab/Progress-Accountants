// This component has been removed as the system uses permanent dark mode
export default function ThemeToggle() {
  return null;
}