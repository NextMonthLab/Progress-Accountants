import { Switch, Route, useLocation } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { useEffect } from "react";
import { useQuery, QueryClient, QueryClientProvider } from "@tanstack/react-query";
import NotFound from "@/pages/not-found";
import { useAuth, AuthProvider } from "@/hooks/use-auth";
import { TenantProvider } from "@/hooks/use-tenant";
import { PermissionsProvider } from "@/hooks/use-permissions";
import { CompanionContextProvider } from "@/hooks/use-companion-context";
import { DualModeCompanion } from "@/components/companions/DualModeCompanion";
import { UpgradeAnnouncement } from "@/components/UpgradeAnnouncement";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { testLogin } from "@/lib/test-login";
import SuperAdminDashboard from "@/pages/super-admin/SuperAdminDashboard";
import HomePage from "@/pages/HomePage";
import StudioPage from "@/pages/StudioPage";
import DashboardPage from "@/pages/DashboardPage";
import AuthPage from "@/pages/AuthPage";
import ClientRegistrationPage from "@/pages/ClientRegistrationPage";
import ClientDashboardPage from "@/pages/ClientDashboardPage";
import CRMViewPage from "@/pages/CRMViewPage";
import CRMViewPageEnhanced from "@/pages/CRMViewPageEnhanced";
import ToolsDashboardPage from "@/pages/ToolsDashboardPage";
import ToolsLandingPage from "@/pages/ToolsLandingPage";
import ComponentDemo from "@/pages/ComponentDemo";
import TeamPage from "@/pages/TeamPage";
import AboutPage from "@/pages/AboutPage";
import ServicesPage from "@/pages/ServicesPage";
import ServiceDetailPage from "@/pages/ServiceDetailPage";
import ContactPage from "@/pages/ContactPage";
import TestimonialsPage from "@/pages/TestimonialsPage";
import ScopeRequestPage from "@/pages/ScopeRequestPage";
import ModuleGalleryPage from "@/pages/ModuleGalleryPage";
import ModuleLibraryPage from "@/pages/ModuleLibraryPage";
import InstalledToolsPage from "@/pages/InstalledToolsPage";
import MarketplacePage from "@/pages/MarketplacePage";
import EnhancedMarketplacePage from "@/pages/EnhancedMarketplacePage";
import BrandGuidelinesPage from "@/pages/BrandGuidelinesPage";
import BusinessIdentityPage from "@/pages/BusinessIdentityPage";
import HomepageSetupPage from "@/pages/HomepageSetupPage";
import FoundationPagesOverviewPage from "@/pages/FoundationPagesOverviewPage";
import AboutSetupPage from "@/pages/AboutSetupPage";
import ServicesSetupPage from "@/pages/ServicesSetupPage";
import ContactSetupPage from "@/pages/ContactSetupPage";
import TestimonialsSetupPage from "@/pages/TestimonialsSetupPage";
import FAQSetupPage from "@/pages/FAQSetupPage";
import LaunchReadyPage from "@/pages/LaunchReadyPage";
import OnboardingWelcomePage from "@/pages/OnboardingWelcomePage";
import WebsiteIntentPage from "@/pages/WebsiteIntentPage";
import AdminSettingsPage from "@/pages/AdminSettingsPage";
import SEOConfigManagerPage from "@/pages/SEOConfigManagerPage";
import BrandManagerPage from "@/pages/BrandManagerPage";
import CompanionSettingsPage from "@/pages/admin/companion-settings";
import BlueprintManagerPage from "@/pages/BlueprintManagerPage";
import MediaManagementPage from "@/pages/MediaManagementPage";
import NewClientOnboarding from "@/pages/NewClientOnboarding";
// Admin settings pages
import TenantCustomizationPage from "@/pages/admin/TenantCustomizationPage";
import ThemeManagementPage from "@/pages/admin/ThemeManagementPage";
// Import wizard components
import CreateFormWizard from "@/pages/tools/wizards/CreateFormWizard";
import CreateCalculatorWizard from "@/pages/tools/wizards/CreateCalculatorWizard";
import CreateDashboardWizard from "@/pages/tools/wizards/CreateDashboardWizard";
import CreateEmbedWizard from "@/pages/tools/wizards/CreateEmbedWizard";
// Import tool pages
import SocialMediaGeneratorPage from "@/pages/tools/social-media-generator";
import { DocumentHead } from "@/components/DocumentHead";
import MainLayout from "@/layouts/MainLayout";
import { ClientDataProvider, withAuth } from "@/components/ClientDataProvider";
import { ThemeProvider } from "@/components/ThemeProvider";

// Protected routes with auth requirements
const ProtectedClientDashboard = withAuth(ClientDashboardPage, 'client');
const ProtectedCRMView = withAuth(CRMViewPage, 'staff');
const ProtectedCRMViewEnhanced = withAuth(CRMViewPageEnhanced, 'staff');
const ProtectedDashboard = withAuth(DashboardPage);
const ProtectedAdminSettings = withAuth(AdminSettingsPage, 'staff');
const ProtectedSEOConfigManager = withAuth(SEOConfigManagerPage, 'staff');
const ProtectedBrandManager = withAuth(BrandManagerPage, 'staff');
const ProtectedBlueprintManager = withAuth(BlueprintManagerPage, 'staff');
const ProtectedTenantCustomization = withAuth(TenantCustomizationPage, 'staff');
const ProtectedThemeManagement = withAuth(ThemeManagementPage, 'staff');

// Router for all application routes
function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/auth" component={AuthPage} />
      <Route path="/client-register/:tenantId" component={ClientRegistrationPage} />
      <Route path="/team" component={TeamPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/services" component={ServicesPage} />
      <Route path="/services/:slug" component={ServiceDetailPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/testimonials" component={TestimonialsPage} />
      <Route path="/" component={HomePage} />

      {/* Super Admin routes (require super admin privileges) */}
      <ProtectedRoute 
        path="/super-admin" 
        component={SuperAdminDashboard} 
        requireSuperAdmin={true} 
      />
      
      {/* Admin routes (require admin or super admin) */}
      <ProtectedRoute 
        path="/admin/crm" 
        component={CRMViewPage} 
        allowedRoles={['admin', 'super_admin', 'editor']} 
      />
      <ProtectedRoute 
        path="/admin/crm-enhanced" 
        component={CRMViewPageEnhanced} 
        allowedRoles={['admin', 'super_admin']} 
      />
      <ProtectedRoute 
        path="/admin/settings" 
        component={AdminSettingsPage} 
        allowedRoles={['admin', 'super_admin']} 
      />
      <ProtectedRoute 
        path="/admin/seo" 
        component={SEOConfigManagerPage} 
        allowedRoles={['admin', 'super_admin', 'editor']} 
      />
      <ProtectedRoute 
        path="/admin/brand" 
        component={BrandManagerPage} 
        allowedRoles={['admin', 'super_admin', 'editor']} 
      />
      <ProtectedRoute 
        path="/admin/blueprint" 
        component={BlueprintManagerPage} 
        allowedRoles={['admin', 'super_admin']} 
      />
      <ProtectedRoute 
        path="/admin/tenant-customization" 
        component={TenantCustomizationPage} 
        allowedRoles={['admin', 'super_admin']} 
      />
      <ProtectedRoute 
        path="/admin/theme-management" 
        component={ThemeManagementPage} 
        allowedRoles={['admin', 'super_admin']} 
      />
      <ProtectedRoute 
        path="/admin/companion-settings" 
        component={CompanionSettingsPage} 
        allowedRoles={['admin', 'super_admin']} 
      />
      <ProtectedRoute 
        path="/admin/new-request" 
        component={ScopeRequestPage} 
        allowedRoles={['admin', 'super_admin', 'editor']} 
      />
      
      {/* Client dashboard routes */}
      <ProtectedRoute 
        path="/client-dashboard" 
        component={DashboardPage} 
        allowedRoles={['client', 'admin', 'super_admin']} 
      />
      <ProtectedRoute 
        path="/client-portal" 
        component={ClientDashboardPage} 
        allowedRoles={['client', 'admin', 'super_admin']} 
      />
      
      {/* Tools and marketplace routes */}
      <ProtectedRoute path="/tools-dashboard" component={ToolsDashboardPage} />
      <ProtectedRoute path="/tools-hub" component={ToolsLandingPage} />
      <ProtectedRoute path="/tools/create/form" component={CreateFormWizard} />
      <ProtectedRoute path="/tools/create/calculator" component={CreateCalculatorWizard} />
      <ProtectedRoute path="/tools/create/dashboard" component={CreateDashboardWizard} />
      <ProtectedRoute path="/tools/create/embed" component={CreateEmbedWizard} />
      <ProtectedRoute 
        path="/tools/social-media-generator" 
        component={SocialMediaGeneratorPage} 
        allowedRoles={['admin', 'super_admin', 'editor']} 
      />
      <ProtectedRoute path="/marketplace" component={EnhancedMarketplacePage} />
      <ProtectedRoute path="/installed-tools" component={InstalledToolsPage} />
      <ProtectedRoute path="/module-gallery" component={MarketplacePage} />
      <ProtectedRoute path="/module-library" component={ModuleLibraryPage} />
      
      {/* Onboarding and setup routes */}
      <ProtectedRoute path="/onboarding" component={OnboardingWelcomePage} />
      <ProtectedRoute path="/new-client-setup" component={NewClientOnboarding} />
      <ProtectedRoute path="/website-intent" component={WebsiteIntentPage} />
      <ProtectedRoute path="/studio-banbury" component={StudioPage} />
      <ProtectedRoute path="/scope-request" component={ScopeRequestPage} />
      <ProtectedRoute path="/brand-guidelines" component={BrandGuidelinesPage} />
      <ProtectedRoute path="/business-identity" component={BusinessIdentityPage} />
      <ProtectedRoute path="/homepage-setup" component={HomepageSetupPage} />
      <ProtectedRoute path="/foundation-pages" component={FoundationPagesOverviewPage} />
      <ProtectedRoute path="/about-setup" component={AboutSetupPage} />
      <ProtectedRoute path="/services-setup" component={ServicesSetupPage} />
      <ProtectedRoute path="/contact-setup" component={ContactSetupPage} />
      <ProtectedRoute path="/testimonials-setup" component={TestimonialsSetupPage} />
      <ProtectedRoute path="/faq-setup" component={FAQSetupPage} />
      <ProtectedRoute path="/launch-ready" component={LaunchReadyPage} />
      <ProtectedRoute path="/media" component={MediaManagementPage} />
      
      {/* Component demo route */}
      <Route path="/components" component={ComponentDemo} />
      
      {/* Fallback 404 route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      gcTime: 1000 * 60 * 30, // 30 minutes (previously called cacheTime)
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider queryClient={queryClient}>
        <PermissionsProvider>
          <ThemeProvider>
            <TenantProvider>
              <CompanionContextProvider>
                <DocumentHead route="/" />
                <FirstTimeUserDetector>
                  <MainLayout>
                    <Router />
                  </MainLayout>
                </FirstTimeUserDetector>
                <DualModeCompanion />
                <UpgradeAnnouncement />
                <Toaster />
              </CompanionContextProvider>
            </TenantProvider>
          </ThemeProvider>
        </PermissionsProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

// Component to detect first-time users and redirect to onboarding
function FirstTimeUserDetector({ children }: { children: React.ReactNode }) {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  
  // Query current location
  const [location] = useLocation();
  
  // Only redirect authenticated non-admin users who haven't completed onboarding
  useEffect(() => {
    // Skip if user is not logged in or is an admin/super admin
    if (!user) return;
    if (user.userType === 'admin' || user.userType === 'super_admin' || user.userType === 'editor') return;
    
    // For demo purposes, we'll redirect based on simple localStorage check
    // In a production environment, this would use the onboardingState from the backend
    const onboardingComplete = localStorage.getItem('project_context.status') === 'onboarded';
    
    // Skip redirection for specific paths that are allowed before onboarding
    const allowedPaths = [
      '/onboarding',
      '/website-intent',
      '/new-client-setup',
      '/client-portal',
      '/tools-dashboard',
      '/tools-hub',
      '/auth',
      '/'
    ];
    
    const isAllowedPath = 
      allowedPaths.includes(location) || 
      location.startsWith('/tools/create/') ||
      location.startsWith('/tools/social-media-generator') ||
      location.startsWith('/homepage-setup') || 
      location.startsWith('/foundation-pages') || 
      location.startsWith('/launch-ready') ||
      location.startsWith('/marketplace');
    
    // If we need to redirect to onboarding
    if (!onboardingComplete && !isAllowedPath) {
      navigate('/onboarding');
    }
  }, [user, location, navigate]);

  return <>{children}</>;
}

export default App;
