import { Switch, Route, useLocation } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import NotFound from "@/pages/not-found";
import { useAuth } from "@/components/ClientDataProvider";
import HomePage from "@/pages/HomePage";
import StudioPage from "@/pages/StudioPage";
import DashboardPage from "@/pages/DashboardPage";
import ClientDashboardPage from "@/pages/ClientDashboardPage";
import CRMViewPage from "@/pages/CRMViewPage";
import CRMViewPageEnhanced from "@/pages/CRMViewPageEnhanced";
import ComponentDemo from "@/pages/ComponentDemo";
import TeamPage from "@/pages/TeamPage";
import AboutPage from "@/pages/AboutPage";
import ServicesPage from "@/pages/ServicesPage";
import ServiceDetailPage from "@/pages/ServiceDetailPage";
import ContactPage from "@/pages/ContactPage";
import ScopeRequestPage from "@/pages/ScopeRequestPage";
import ModuleGalleryPage from "@/pages/ModuleGalleryPage";
import ModuleLibraryPage from "@/pages/ModuleLibraryPage";
import MarketplacePage from "@/pages/MarketplacePage.fixed";
import BrandGuidelinesPage from "@/pages/BrandGuidelinesPage";
import BusinessIdentityPage from "@/pages/BusinessIdentityPage";
import HomepageSetupPage from "@/pages/HomepageSetupPage";
import FoundationPagesOverviewPage from "@/pages/FoundationPagesOverviewPage";
import LaunchReadyPage from "@/pages/LaunchReadyPage";
import OnboardingWelcomePage from "@/pages/OnboardingWelcomePage";
import AdminSettingsPage from "@/pages/AdminSettingsPage";
import SEOConfigManagerPage from "@/pages/SEOConfigManagerPage";
import BrandManagerPage from "@/pages/BrandManagerPage";
import BlueprintManagerPage from "@/pages/BlueprintManagerPage";
import MediaManagementPage from "@/pages/MediaManagementPage";
import { DocumentHead } from "@/components/DocumentHead";
import MainLayout from "@/layouts/MainLayout";
import { ClientDataProvider, withAuth } from "@/components/ClientDataProvider";

// Protected routes with auth requirements
const ProtectedClientDashboard = withAuth(ClientDashboardPage, 'client');
const ProtectedCRMView = withAuth(CRMViewPage, 'staff');
const ProtectedCRMViewEnhanced = withAuth(CRMViewPageEnhanced, 'staff');
const ProtectedDashboard = withAuth(DashboardPage);
const ProtectedAdminSettings = withAuth(AdminSettingsPage, 'staff');
const ProtectedSEOConfigManager = withAuth(SEOConfigManagerPage, 'staff');
const ProtectedBrandManager = withAuth(BrandManagerPage, 'staff');
const ProtectedBlueprintManager = withAuth(BlueprintManagerPage, 'staff');

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/onboarding" component={OnboardingWelcomePage} />
      <Route path="/studio-banbury" component={StudioPage} />
      <Route path="/client-dashboard" component={ProtectedDashboard} />
      <Route path="/client-portal" component={ProtectedClientDashboard} />
      <Route path="/admin/crm" component={ProtectedCRMView} />
      <Route path="/admin/crm-enhanced" component={ProtectedCRMViewEnhanced} />
      <Route path="/components" component={ComponentDemo} />
      <Route path="/team" component={TeamPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/services" component={ServicesPage} />
      <Route path="/services/:slug" component={ServiceDetailPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/admin/new-request" component={ScopeRequestPage} />
      <Route path="/admin/settings" component={ProtectedAdminSettings} />
      <Route path="/admin/seo" component={ProtectedSEOConfigManager} />
      <Route path="/admin/brand" component={ProtectedBrandManager} />
      <Route path="/admin/blueprint" component={ProtectedBlueprintManager} />
      <Route path="/scope-request" component={ScopeRequestPage} />
      <Route path="/module-gallery" component={ModuleGalleryPage} />
      <Route path="/module-library" component={ModuleLibraryPage} />
      <Route path="/marketplace" component={MarketplacePage} />
      <Route path="/brand-guidelines" component={BrandGuidelinesPage} />
      <Route path="/business-identity" component={BusinessIdentityPage} />
      <Route path="/homepage-setup" component={HomepageSetupPage} />
      <Route path="/foundation-pages" component={FoundationPagesOverviewPage} />
      <Route path="/launch-ready" component={LaunchReadyPage} />
      <Route path="/media" component={MediaManagementPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ClientDataProvider>
      <DocumentHead route="/" />
      <FirstTimeUserDetector>
        <MainLayout>
          <Router />
        </MainLayout>
      </FirstTimeUserDetector>
      <Toaster />
    </ClientDataProvider>
  );
}

// Component to detect first-time users and redirect to onboarding
function FirstTimeUserDetector({ children }: { children: React.ReactNode }) {
  const [, navigate] = useLocation();
  const { userId, userType } = useAuth();
  
  // Query the user's onboarding state
  const { data: onboardingState, isLoading } = useQuery({
    queryKey: [`/api/onboarding/${userId}`],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/onboarding/${userId}`);
        if (!response.ok) return null;
        return response.json();
      } catch (error) {
        console.error("Error fetching onboarding state:", error);
        return null;
      }
    },
  });

  // Query current location
  const [location] = useLocation();
  
  // Only redirect client users who don't have complete onboarding
  useEffect(() => {
    // For demo purposes, we'll redirect based on simple localStorage check
    // In a production environment, this would use the onboardingState from the backend
    const onboardingComplete = localStorage.getItem('project_context.status') === 'onboarded';
    
    // Check for client user and incomplete onboarding
    if (userType === 'client' && 
        !onboardingComplete &&
        location !== '/onboarding' && 
        !location.startsWith('/homepage-setup') && 
        !location.startsWith('/foundation-pages') && 
        !location.startsWith('/launch-ready') &&
        !location.startsWith('/marketplace')) {
      
      // Redirect to onboarding
      navigate('/onboarding');
    }
  }, [userType, location, navigate]);

  return <>{children}</>;
}

export default App;
