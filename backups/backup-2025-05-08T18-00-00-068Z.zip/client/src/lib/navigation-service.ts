import { 
  NavigationItem, 
  NavigationLink, 
  NavigationSubmenu, 
  NavigationItemCategory
} from '@/types/navigation';

// Map the current sidebar items to our new navigation structure
export const mapSidebarToNavigation = (): NavigationItem[] => {
  // This is a conversion function that allows us to transform our current
  // sidebar structure into the new dynamic navigation system format
  
  const navigationItems: NavigationItem[] = [
    // FREQUENTLY USED SECTION
    // ======================
    {
      id: 'view_website',
      title: 'View Website',
      icon: 'Globe',
      type: 'link',
      href: '/',
      description: 'Open your public website in a new tab',
      category: 'frequently_used',
      pinnedOrder: 1,
    },
    {
      id: 'dashboard',
      title: 'Dashboard',
      icon: 'LayoutDashboard',
      type: 'link',
      href: '/admin/dashboard',
      description: 'View your site performance at a glance',
      badge: { text: 'Upgraded', variant: 'updated' },
      category: 'frequently_used',
      pinnedOrder: 2,
    },
    {
      id: 'page_builder',
      title: 'Page Builder',
      icon: 'Layers',
      type: 'submenu',
      items: [
        {
          id: 'all_pages',
          title: 'All Pages',
          icon: 'FileText',
          type: 'link',
          href: '/page-builder',
          requiresStaff: true,
          category: 'frequently_used',
        },
        {
          id: 'create_page',
          title: 'Create New Page',
          icon: 'PlusCircle',
          type: 'link',
          href: '/page-builder/new',
          requiresStaff: true,
          badge: { text: 'Updated', variant: 'updated' },
          category: 'frequently_used',
        },
        {
          id: 'page_templates',
          title: 'Page Templates',
          icon: 'Layout',
          type: 'link',
          href: '/page-builder/templates',
          requiresStaff: true,
          category: 'frequently_used',
        }
      ],
      requiresStaff: true,
      category: 'frequently_used',
      pinnedOrder: 2,
    },
    {
      id: 'media_hub',
      title: 'Media Library',
      icon: 'FileImage',
      type: 'link',
      href: '/media',
      requiresStaff: true,
      description: 'Manage images, videos and documents',
      badge: { text: 'Enhanced', variant: 'updated' },
      category: 'frequently_used',
      pinnedOrder: 3,
    },
    {
      id: 'marketplace',
      title: 'Marketplace',
      icon: 'ShoppingCart',
      type: 'link',
      href: '/marketplace',
      badge: { text: 'New Tools', variant: 'new' },
      description: 'Discover and install powerful tools',
      category: 'frequently_used',
      pinnedOrder: 4,
    },
    
    // CONTENT CREATION
    // ===============
    {
      id: 'homepage_setup',
      title: 'Homepage Builder',
      icon: 'Home',
      type: 'link',
      href: '/homepage-setup',
      requiresStaff: true,
      description: 'Configure your site homepage',
      category: 'page_builders',
    },
    {
      id: 'foundation_pages',
      title: 'Foundation Pages',
      icon: 'Layout',
      type: 'link',
      href: '/foundation-pages',
      requiresStaff: true,
      description: 'Manage essential pages',
      category: 'page_builders',
    },
    {
      id: 'launch_ready',
      title: 'Launch Checklist',
      icon: 'FastForward',
      type: 'link',
      href: '/launch-ready',
      requiresStaff: true,
      description: 'Prepare your site for launch',
      category: 'page_builders',
    },
    {
      id: 'social_media_generator',
      title: 'Social Media Content',
      icon: 'Share2',
      type: 'link',
      href: '/tools/social-media-generator',
      requiresStaff: true,
      description: 'Create optimized social media posts',
      badge: { text: 'AI-Powered', variant: 'new' },
      category: 'creator_tools',
    },
    {
      id: 'blog_post_generator',
      title: 'Blog Content',
      icon: 'FileText',
      type: 'link',
      href: '/tools/blog-post-generator',
      requiresStaff: true,
      description: 'Generate SEO-optimized blog posts',
      badge: { text: 'AI-Powered', variant: 'new' },
      category: 'creator_tools',
    },
    
    // ANALYTICS & INSIGHTS
    // ===================
    {
      id: 'analytics',
      title: 'Site Analytics',
      icon: 'BarChart',
      type: 'link',
      href: '/admin/analytics',
      requiresStaff: true,
      description: 'Traffic, user behavior and conversions',
      badge: { text: 'Real-time', variant: 'new' },
      category: 'admin_tools',
    },
    {
      id: 'insights_dashboard',
      title: 'Business Insights',
      icon: 'TrendingUp',
      type: 'link',
      href: '/admin/insights-dashboard',
      requiresStaff: true,
      description: 'Actionable business intelligence',
      badge: { text: 'New', variant: 'new' },
      category: 'admin_tools',
    },
    {
      id: 'crm',
      title: 'Client CRM',
      icon: 'Users',
      type: 'link',
      href: '/admin/crm',
      requiresStaff: true,
      description: 'Manage client relationships',
      badge: { text: 'Pro', variant: 'pro' },
      category: 'admin_tools',
    },
    
    // WEBSITE SETTINGS
    // ==============
    {
      id: 'navigation_menus',
      title: 'Navigation Menus',
      icon: 'ListOrdered',
      type: 'link',
      href: '/admin/menu-management',
      requiresStaff: true,
      description: 'Configure site navigation',
      category: 'website_setup',
    },
    {
      id: 'seo_manager',
      title: 'SEO Settings',
      icon: 'Search',
      type: 'link',
      href: '/admin/seo',
      requiresStaff: true,
      description: 'Optimize for search engines',
      category: 'website_setup',
    },
    {
      id: 'domain_settings',
      title: 'Domain Settings',
      icon: 'Link',
      type: 'link',
      href: '/admin/domain-mapping',
      requiresStaff: true,
      description: 'Manage custom domains',
      badge: { text: 'New', variant: 'new' },
      category: 'website_setup',
    },
    
    // BRAND CENTER
    // ===========
    {
      id: 'brand_guidelines',
      title: 'Brand Guidelines',
      icon: 'PaintBucket',
      type: 'link',
      href: '/brand-guidelines',
      requiresStaff: true,
      description: 'Define your brand identity',
      category: 'brand_center',
    },
    {
      id: 'business_identity',
      title: 'Business Profile',
      icon: 'CircleUser',
      type: 'link',
      href: '/business-identity',
      requiresStaff: true,
      description: 'Your company information',
      category: 'brand_center',
    },
    {
      id: 'site_branding',
      title: 'Visual Branding',
      icon: 'Palette',
      type: 'link',
      href: '/admin/site-branding',
      requiresStaff: true,
      description: 'Logo, colors and visual elements',
      category: 'brand_center',
    },

    // GROWTH & NETWORKING
    // ==================
    {
      id: 'business_network',
      title: 'Business Network',
      icon: 'Network',
      type: 'link',
      href: '/business-network',
      description: 'Connect with other businesses',
      badge: { text: 'New', variant: 'new' },
      category: 'personal_growth',
    },
    {
      id: 'business_discover',
      title: 'Discover',
      icon: 'Globe',
      type: 'link',
      href: '/business-discover',
      description: 'Find new opportunities',
      badge: { text: 'New', variant: 'new' },
      category: 'personal_growth',
    },
    {
      id: 'entrepreneur_support',
      title: 'Entrepreneur Resources',
      icon: 'Lightbulb',
      type: 'link',
      href: '/entrepreneur-support',
      description: 'Tools to help your business grow',
      badge: { text: 'New', variant: 'new' },
      category: 'personal_growth',
    },
    
    // SYSTEM & ADMINISTRATION
    // ======================
    {
      id: 'account',
      title: 'My Account',
      icon: 'User',
      type: 'link',
      href: '/account',
      description: 'Manage your user account',
      category: 'system',
    },
    {
      id: 'admin_settings',
      title: 'System Settings',
      icon: 'Settings',
      type: 'link',
      href: '/admin/settings',
      requiresStaff: true,
      description: 'Configure system preferences',
      category: 'system',
    },
    {
      id: 'ai_companion',
      title: 'AI Assistant Settings',
      icon: 'Bot',
      type: 'link',
      href: '/admin/companion-settings',
      requiresStaff: true,
      description: 'Configure AI behavior',
      category: 'system',
    },
    {
      id: 'diagnostics_dashboard',
      title: 'System Health',
      icon: 'ActivitySquare',
      type: 'link',
      href: '/diagnostics',
      requiresStaff: true,
      requiresSuperAdmin: false,
      description: 'Monitor system performance',
      badge: { text: 'Admin', variant: 'pro' },
      category: 'system',
    },
    {
      id: 'site_inventory',
      title: 'Site Inventory',
      icon: 'ClipboardList',
      type: 'link',
      href: '/admin/site-inventory',
      requiresStaff: true,
      description: 'Snapshot of site content',
      badge: { text: 'New', variant: 'new' },
      category: 'system',
    },
    {
      id: 'sot_management',
      title: 'Source of Truth',
      icon: 'Shield',
      type: 'link',
      href: '/admin/sot-management',
      requiresStaff: true,
      requiresSuperAdmin: true,
      description: 'System registry and core data',
      badge: { text: 'Admin', variant: 'pro' },
      category: 'system',
    },
    {
      id: 'blueprint_management',
      title: 'Blueprint Management',
      icon: 'Cpu',
      type: 'link',
      href: '/admin/blueprint-management',
      requiresStaff: true,
      requiresSuperAdmin: true,
      description: 'Manage system blueprints',
      badge: { text: 'Admin', variant: 'pro' },
      category: 'system',
    },
    {
      id: 'clone_template',
      title: 'Site Templates',
      icon: 'Copy',
      type: 'link',
      href: '/admin/clone-template',
      requiresStaff: true,
      requiresSuperAdmin: true,
      description: 'Template management',
      badge: { text: 'Admin', variant: 'pro' },
      category: 'system',
    },
  ];
  
  return navigationItems;
};

// Function to fetch navigation data from the API (or mock data for now)
export const fetchNavigationData = async (): Promise<NavigationItem[]> => {
  try {
    // In a real implementation, this would fetch from the API
    // For now, return the mapped data
    return Promise.resolve(mapSidebarToNavigation());
  } catch (error) {
    console.error('Error fetching navigation data:', error);
    return [];
  }
};