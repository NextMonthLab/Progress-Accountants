# NextMonth Gold UI - Design Reference Blueprint v1.0.0

This document serves as the official design reference blueprint for all NextMonth products and tools. Based on the Lead Tracker as the gold standard reference screen in both dark and light modes, this blueprint provides comprehensive guidance for maintaining visual consistency across the entire product suite.

## Table of Contents
1. [Design Foundations](#design-foundations)
2. [Component Library](#component-library)
3. [Layout Structure](#layout-structure)
4. [Color System](#color-system)
5. [Typography](#typography)
6. [Spacing & Sizing](#spacing--sizing)
7. [Interaction Patterns](#interaction-patterns)
8. [Responsive Behavior](#responsive-behavior)
9. [Animation Guidelines](#animation-guidelines)
10. [Implementation Guide](#implementation-guide)

---

## Design Foundations

### Theme Variants
The application supports two primary theme modes: **Dark** and **Light**. All components must be designed with both themes in mind.

#### Dark Mode Foundation
- **Background**: `dark:bg-black` for page background, `dark:bg-[#0A0A0A]` for containers
- **Text**: `dark:text-white` for headings, `dark:text-[#E0E0E0]` for body text, `dark:text-[#9E9E9E]` for muted text
- **Borders**: `dark:border-[#1D1D1D]` for standard borders, `dark:border-[#3A3A3A]` for emphasized borders
- **Cards/Containers**: `dark:bg-[#0A0A0A]` with `dark:border-[#1D1D1D]`
- **Interactive Elements**: `dark:bg-[#121212]` for buttons and interactive controls

#### Light Mode Foundation
- **Background**: `bg-white` or `bg-gray-50` for page background
- **Text**: `text-gray-900` for headings, `text-gray-700` for body text, `text-gray-500` for muted text
- **Borders**: `border-gray-200` for standard borders, `border-gray-300` for emphasized borders
- **Cards/Containers**: `bg-white` with `border-gray-200`
- **Interactive Elements**: `bg-gray-50` for buttons and interactive controls

### Brand Gradients
- **Primary Gradient**: `bg-gradient-to-r from-[#3CBFAE] to-[#F65C9A]`
- Usage: Action buttons, accent text, progress indicators, and highlight elements
- Apply using `bg-clip-text text-transparent` for gradient text

### Grid Overlay
- Apply subtle grid patterns with:
```css
<div className="absolute inset-0 dark:bg-grid-white/[0.02] bg-grid-black/[0.02] [mask-image:linear-gradient(to_bottom,white,transparent)]"></div>
```

---

## Component Library

### Premium Cards

The `PremiumCard` component is the foundation for content containers throughout the application. It has several variants and subcomponents:

#### Base Card
```jsx
<PremiumCard 
  variant="default" // Options: default, primary, secondary, subtle
  className="shadow-sm"
>
  {children}
</PremiumCard>
```

| Property | Description |
|----------|-------------|
| `variant` | Determines card styling: default (neutral), primary (pink accent), secondary (teal accent), subtle (darker background) |
| `hover` | Enables hover effects |
| `interactive` | Makes the card respond to user interactions |
| `animated` | Enables entrance animations |

#### Card Structure
- **PremiumCardHeader**: Container for the card title, with optional border
- **PremiumCardTitle**: Card title with optional icon
- **PremiumCardContent**: Main content area with padding
- **PremiumCardFooter**: Optional footer with top border
- **PremiumCardBadge**: Badge/label with multiple variants

Example structure:
```jsx
<PremiumCard>
  <PremiumCardHeader>
    <PremiumCardTitle icon={<Icon />}>Title</PremiumCardTitle>
  </PremiumCardHeader>
  <PremiumCardContent>
    Content goes here
  </PremiumCardContent>
  <PremiumCardFooter>
    Footer actions
  </PremiumCardFooter>
</PremiumCard>
```

### Statistics Cards

The `StatCard` component is used for displaying metrics and KPIs:

```jsx
<StatCard
  label="Total Leads"
  value="124"
  icon={<Users className="h-4 w-4" />}
  trend={{ value: 12, direction: "up" }}
  chartData={[4, 7, 5, 10, 15, 12, 8]}
  variant="default" // Options: default, success, warning, danger, info
/>
```

Group stat cards with:
```jsx
<StatCardGroup columns={4}>
  <StatCard ... />
  <StatCard ... />
</StatCardGroup>
```

### Lead Cards

The `LeadCard` component displays lead information:

```jsx
<LeadCard 
  company={{
    name: "Company Name",
    firstLetter: "C"
  }}
  score={85}
  insights="AI-generated insights about the lead"
  tags={["High Intent", "Returning", "USA"]}
  metrics={{
    visits: 12,
    pages: 5,
    avgTime: "3m 45s",
    lastVisit: "Today"
  }}
/>
```

Group lead cards with:
```jsx
<LeadCardGrid columns={2}>
  <LeadCard ... />
  <LeadCard ... />
</LeadCardGrid>
```

### Dashboard Components

Specialized components for dashboards:

- **DashboardHeader**: Page title section with actions
- **DashboardSection**: Content section with optional title
- **DashboardFilterBar**: Filter controls container
- **DashboardFilterBadge**: Individual filter option
- **DashboardTabs**: Custom tab navigation
- **DashboardTab**: Individual tab item
- **DashboardContent**: Main content container

### Buttons

Primary action button with gradient:
```jsx
<Button 
  className="bg-gradient-to-r from-[#3CBFAE] to-[#F65C9A] hover:opacity-90 text-white border-0 shadow-lg hover:shadow-[0_4px_16px_rgba(246,92,154,0.25)] transition-all duration-300"
>
  <Icon className="mr-2 h-4 w-4" />
  Button Text
</Button>
```

Secondary/outline button:
```jsx
<Button 
  variant="outline" 
  className="dark:border-[#3A3A3A] border-gray-300 dark:bg-[#121212]/80 bg-gray-50 dark:hover:bg-[#1D1D1D] hover:bg-gray-100 transition-all dark:text-white text-gray-800"
>
  <Icon className="mr-2 h-4 w-4 text-[#F65C9A]" />
  Button Text
</Button>
```

### Theme Toggle

```jsx
<ThemeToggle />
```

Implementation in `theme-toggle.tsx`:
```jsx
<button
  onClick={toggleTheme}
  className={`h-9 w-9 rounded-full flex items-center justify-center ${
    isDarkTheme 
      ? "bg-nextmonth-purple/20 hover:bg-nextmonth-purple/30 shadow-md" 
      : "bg-gray-200 hover:bg-gray-300 border border-gray-300 shadow-md"
  } transition-all duration-200`}
  title={`Switch to ${isDarkTheme ? "light" : "dark"} mode`}
>
  {isDarkTheme ? (
    <Sun className="h-5 w-5 text-yellow-300" />
  ) : (
    <Moon className="h-5 w-5 text-blue-700" />
  )}
</button>
```

### Navigation

Tab navigation style:
```jsx
<div className="dark:bg-[#0A0A0A] bg-white dark:border-[#1D1D1D] border-gray-200 grid grid-cols-5 w-full rounded-lg overflow-hidden shadow-sm">
  <button 
    className={`dark:text-white text-gray-800 py-3 px-4 flex items-center gap-2 text-sm font-medium transition-colors ${
      activeTab === 'tab-name' 
        ? 'dark:bg-[#121212] bg-gray-50 dark:text-white text-gray-900 border-b-2 border-[#F65C9A]' 
        : 'dark:text-[#9E9E9E] text-gray-600 border-b-2 border-transparent'
    }`}
  >
    <Icon className="w-4 h-4" />
    Tab Name
  </button>
  {/* Additional tabs */}
</div>
```

---

## Layout Structure

### Page Structure
Standard page layout:
```jsx
<div className="container mx-auto py-8 space-y-8 dark:bg-black bg-gray-50">
  {/* Hero Section */}
  <div className="relative overflow-hidden rounded-xl dark:bg-[#0A0A0A] bg-white p-8 shadow-md dark:border-[#1D1D1D] border-gray-200">
    {/* Grid overlay */}
    <div className="absolute inset-0 dark:bg-grid-white/[0.02] bg-grid-black/[0.02] [mask-image:linear-gradient(to_bottom,white,transparent)]"></div>
    
    {/* Theme toggle */}
    <div className="absolute top-4 right-4 z-10">
      <ThemeToggle />
    </div>
    
    {/* Header content */}
    <div className="relative flex flex-col md:flex-row justify-between md:items-center gap-6">
      {/* Title & buttons */}
      {/* Stats/credits display */}
    </div>
    
    {/* Background decoration */}
    <div className="absolute bottom-0 right-0 opacity-10">
      <Icon className="h-60 w-60 text-[#F65C9A]" />
    </div>
  </div>
  
  {/* Navigation */}
  <div className="navigation-tabs">...</div>
  
  {/* Page content */}
  <div className="content-section">...</div>
</div>
```

### Grid System
- Main container: `container mx-auto`
- Standard spacing: `space-y-8` for vertical, `gap-6` for grid gaps
- Card grids:
  - 4 columns: `grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4`
  - 3 columns: `grid grid-cols-1 sm:grid-cols-3 gap-4`
  - 2 columns: `grid grid-cols-1 md:grid-cols-2 gap-4`

### Margins & Padding
- **Container**: `p-8` for large containers
- **Cards**: `p-6` for card content, `px-6 py-4` for card headers
- **Elements**: `gap-4` or `gap-6` for spacing between elements

---

## Color System

### Primary Colors
- **Teal**: `#3CBFAE` - Used for success indicators, secondary buttons
- **Pink**: `#F65C9A` - Used for primary actions, highlights, attention areas

### Background Colors
- **Dark Mode**:
  - Page: `black`
  - Container: `#0A0A0A`
  - Card: `#0A0A0A`
  - Interactive: `#121212`
  - Hover: `#1A1A1A`
  - Border: `#1D1D1D` (light border), `#3A3A3A` (heavy border)

- **Light Mode**:
  - Page: `white` or `gray-50`
  - Container: `white`
  - Card: `white`
  - Interactive: `gray-50`
  - Hover: `gray-100`
  - Border: `gray-200` (light border), `gray-300` (heavy border)

### Text Colors
- **Dark Mode**:
  - Heading: `white` 
  - Body: `#E0E0E0`
  - Muted: `#9E9E9E`

- **Light Mode**:
  - Heading: `gray-900`
  - Body: `gray-700`
  - Muted: `gray-500`

### Functional Colors
- **Success**: `#3CBFAE` (teal)
- **Warning**: `#FFC107` (amber)
- **Error**: `#F43F5E` (rose/red)
- **Info**: `#38BDF8` (blue)

---

## Typography

### Font Stacks
Default system font stack through Tailwind's `font-sans`

### Text Sizes
- Page title: `text-4xl font-bold tracking-tight`
- Section title: `text-2xl font-semibold`
- Card title: `text-xl font-semibold`
- Subtitle: `text-lg font-medium`
- Body: `text-base`
- Small text: `text-sm`
- Micro text: `text-xs`

### Font Weights
- Bold: `font-bold` for page titles and emphasis
- Semibold: `font-semibold` for card titles and headings
- Medium: `font-medium` for subtitles and navigation
- Regular: default weight for body text

---

## Spacing & Sizing

### Container Width
- Standard container: `container mx-auto`

### Responsive Breakpoints
- Small (sm): 640px and up
- Medium (md): 768px and up
- Large (lg): 1024px and up
- Extra Large (xl): 1280px and up
- 2XL (2xl): 1536px and up

### Element Sizes
- Icons: `h-4 w-4` (small), `h-5 w-5` (medium), `h-6 w-6` (large)
- Buttons: `px-4 py-2` (standard), `px-3 py-1.5` (small)
- Avatars: `w-12 h-12` (standard), `w-9 h-9` (small)
- Border radius: `rounded-lg` (standard), `rounded-xl` (cards), `rounded-full` (avatars, badges)

---

## Interaction Patterns

### Hover States
- Cards: `hover:dark:border-[#3A3A3A] hover:border-gray-300 transition-all duration-300`
- Buttons:
  - Primary: `hover:opacity-90 hover:shadow-[0_4px_16px_rgba(246,92,154,0.25)]`
  - Secondary: `dark:hover:bg-[#1D1D1D] hover:bg-gray-100`

### Active States
- Tabs: `data-[state=active]:dark:bg-[#121212] data-[state=active]:bg-gray-50 data-[state=active]:dark:text-white data-[state=active]:text-gray-900 data-[state=active]:border-b-2 data-[state=active]:border-[#F65C9A]`

### Focus States
- Default Tailwind focus ring

### Loading States
- Skeleton loading: `animate-pulse dark:bg-[#3A3A3A] bg-gray-200`
- Spinner: `animate-spin` with icon

---

## Responsive Behavior

### Mobile First Approach
Default styles apply to mobile, with responsive classes for larger screens

### Layout Changes
- **Stack to row**: 
  ```jsx
  <div className="flex flex-col md:flex-row">...</div>
  ```
- **Column count**: 
  ```jsx
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">...</div>
  ```
- **Responsive padding**:
  ```jsx
  <div className="p-4 md:p-6 lg:p-8">...</div>
  ```

### Element Hiding/Showing
- Show on desktop only: `hidden md:block`
- Show on mobile only: `md:hidden`

---

## Animation Guidelines

### Entrance Animations
Using Framer Motion:
```jsx
<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ 
    duration: 0.5, 
    ease: [0.22, 1, 0.36, 1]
  }}
>
  {content}
</motion.div>
```

### Hover Animations
```jsx
<motion.button 
  whileHover={{ scale: 1.03 }}
  whileTap={{ scale: 0.98 }}
>
  Button Text
</motion.button>
```

### Loading & Progress
- Spinner: `animate-spin`
- Skeleton: `animate-pulse`
- Progress bar: Match styling with primary gradient

---

## Implementation Guide

### Theme Configuration
Base colors in `theme.json`:
```json
{
  "primary": "#F65C9A",
  "variant": "professional",
  "appearance": "system",
  "radius": 0.75
}
```

### CSS Pattern Usage
- Always use the `dark:` variant for dark mode styles
- Prefer utility classes over custom CSS
- Use consistent pattern for container backgrounds:
  - `dark:bg-[#0A0A0A] bg-white`
  - Avoid using non-themeable styles like `bg-black`

### Adding New Components
1. Follow the existing naming pattern (e.g., `PremiumCard`, `StatCard`)
2. Create proper interfaces with optional props
3. Support both dark and light themes
4. Implement consistent spacing
5. Use proper refs and forwarding

### Event Handling
- Buttons should have proper hover/focus/active states
- Interactive elements should have appropriate cursor styles
- Use appropriate visual feedback for user actions

### Icon Usage
- Use Lucide React icons or SVGs with consistent styling
- Icons in buttons: `mr-2 h-4 w-4`
- Standalone icons: Appropriate sizing (h-4, h-5, h-6)
- Background decorative icons: large size with low opacity

---

## Component Examples

### Action Button
```jsx
<Button className="bg-gradient-to-r from-[#3CBFAE] to-[#F65C9A] hover:opacity-90 text-white border-0 shadow-lg hover:shadow-[0_4px_16px_rgba(246,92,154,0.25)] transition-all duration-300">
  <Icon className="mr-2 h-4 w-4" />
  Button Text
</Button>
```

### Stat Card
```jsx
<div className="dark:bg-[#0A0A0A] bg-white dark:border-[#1D1D1D] border-gray-200 p-5 rounded-xl shadow-md relative overflow-hidden group hover:dark:border-[#3A3A3A] hover:border-gray-300 transition-all duration-300">
  <div className="absolute top-0 right-0 p-2 opacity-10">
    <Icon className="h-16 w-16 text-[#F65C9A]" />
  </div>
  <div className="relative">
    <h3 className="dark:text-[#9E9E9E] text-gray-500 text-sm font-medium">Stat Label</h3>
    <div className="mt-2 flex items-baseline">
      <span className="text-3xl font-bold dark:text-white text-gray-900">123</span>
      <span className="ml-1 text-xs dark:text-[#9E9E9E] text-gray-500">items</span>
    </div>
    <div className="mt-3 text-xs dark:text-[#9E9E9E] text-gray-500 flex items-center gap-1.5">
      <Icon className="h-3.5 w-3.5 text-[#F65C9A]" />
      <span>Descriptive text</span>
    </div>
  </div>
</div>
```

### Page Header
```jsx
<div className="relative overflow-hidden rounded-xl dark:bg-[#0A0A0A] bg-white p-8 shadow-md dark:border-[#1D1D1D] border-gray-200">
  <div className="absolute inset-0 dark:bg-grid-white/[0.02] bg-grid-black/[0.02] [mask-image:linear-gradient(to_bottom,white,transparent)]"></div>
  
  <div className="relative flex flex-col md:flex-row justify-between md:items-center gap-6">
    <div>
      <div className="mb-4">
        <LogoComponent size="md" />
      </div>
      
      <h1 className="text-4xl font-bold tracking-tight dark:text-white text-gray-900">
        Product <span className="bg-gradient-to-r from-[#3CBFAE] to-[#F65C9A] bg-clip-text text-transparent">Name</span>
      </h1>
      <p className="dark:text-[#E0E0E0] text-gray-700 mt-2 text-lg max-w-xl">
        Product description here
      </p>
      
      <div className="flex flex-wrap gap-4 mt-6">
        <Button className="bg-gradient-to-r from-[#3CBFAE] to-[#F65C9A] hover:opacity-90 text-white border-0 shadow-lg hover:shadow-[0_4px_16px_rgba(246,92,154,0.25)] transition-all duration-300">
          <Icon className="mr-2 h-4 w-4" />
          Primary Action
        </Button>
        <Button variant="outline" className="dark:border-[#3A3A3A] border-gray-300 dark:bg-[#121212]/80 bg-gray-50 dark:hover:bg-[#1D1D1D] hover:bg-gray-100 transition-all dark:text-white text-gray-800">
          <Icon className="mr-2 h-4 w-4 text-[#F65C9A]" />
          Secondary Action
        </Button>
      </div>
    </div>
    
    <div className="flex items-center gap-4 dark:bg-[#121212] bg-gray-100 backdrop-blur-sm p-5 rounded-lg shadow-inner dark:border-[#3A3A3A] border-gray-300">
      <div className="text-sm font-medium dark:text-[#E0E0E0] text-gray-700">Credits</div>
      <div className="text-sm font-semibold tabular-nums dark:text-white text-gray-900">35/100</div>
    </div>
  </div>
  
  <div className="absolute bottom-0 right-0 opacity-10">
    <Icon className="h-60 w-60 text-[#F65C9A]" />
  </div>
</div>
```